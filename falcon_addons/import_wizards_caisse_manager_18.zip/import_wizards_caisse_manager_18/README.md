# Import Wizards Importer (Odoo 18)

> **Two-step Excel import (Test → Import)** for Products, Locations, and Bills of Materials — designed for manufacturing rollouts at scale.

<p align="center">
  <img src="https://img.shields.io/badge/Odoo-18.0-8743CC?logo=odoo&logoColor=white" />
  <img src="https://img.shields.io/badge/Module-Import%20Wizards-1f6feb" />
  <img src="https://img.shields.io/badge/License-LGPL--3-black" />
  <img src="https://img.shields.io/badge/Excel-openpyxl-blue" />
</p>

---

## ✨ Highlights

- **Two-step flow:** **Test** your file → get row-by-row validation → **Import** safely.
- **Manufacturing-ready:** imports **Products** (raw / semi-finished / finished), **BoMs**, and **Stock Locations**.
- **Excel-first:** `.xlsx` parsing via **openpyxl** with multilingual header aliases (FR/EN).
- **Guided UI:** central **Import Center** with shortcuts for each data type.
- **Non-destructive:** validation before write; clear errors with line numbers.
- **Extra fields:** product type tag: _matière première_ / _semi-fini_ / _fini_.

> Module root: `import_wizards_caisse_manager_18` · Version: **18.0.2.0.0** · Author: **Rida Louchachha**

---

## 🧭 Table of Contents

- [What You Can Import](#what-you-can-import)
- [Screens & Flow](#screens--flow)
- [Installation](#installation)
- [Configuration](#configuration)
- [How to Use](#how-to-use)
- [Excel Templates](#excel-templates)
- [Validation & Matching](#validation--matching)
- [Access Rights](#access-rights)
- [Troubleshooting](#troubleshooting)
- [Technical Notes](#technical-notes)
- [License](#license)

---

## ✅ What You Can Import

- **Product Categories** (`product.category`) — tree paths supported.
- **Products** (`product.template` & `product.product`)
  - Type métier (**CM Product Type**): _matière première_ / _semi-fini_ / _fini_.
- **Bills of Materials**
  - **Fabricated / Semi-finished** (`mrp.bom` for fabricated items)
  - **Finished** (`mrp.bom` for finished items)
- **Stock Locations** (`stock.location`) — usage mapping (internal, view, supplier, customer, inventory, production, transit).

> Dependencies: `product`, `stock`, `mrp`

---

## 🎬 Screens & Flow

Place your GIFs under `.github/demo/` and update the links below.

- **Import Center**
  <img src="https://raw.githubusercontent.com/your-org/your-repo/main/.github/demo/import-center.gif" width="85%" />

- **Wizard: Test → Import**
  <img src="https://raw.githubusercontent.com/your-org/your-repo/main/.github/demo/test-import.gif" width="85%" />

- **BoM Import Result**
  <img src="https://raw.githubusercontent.com/your-org/your-repo/main/.github/demo/bom-import.gif" width="85%" />

---

## 📦 Installation

1. Put the module in your addons path:
   ```bash
   git clone https://github.com/<your-account>/<your-repo>.git
   ```
2. Ensure **Python dependency** is available:
   ```bash
   pip install openpyxl
   ```
3. Update Apps → search **Import Wizards Caisse Manager** → **Install**  
   (_technical name_: `import_wizards_caisse_manager_18`)

---

## ⚙️ Configuration

- **Excel engine:** requires **openpyxl**.
- **Product Type (CM):** adds `product_type_cm` on templates and variants for métier classification.
- **Menus:** a centralized **Import Center** plus dedicated actions for Products, Categories, BoMs, and Locations.

---

## 🚀 How to Use

**Menu:** `Inventory → Operations → Import Center`

1. Choose what to import (Categories, Products, BoMs, Locations).
2. **Upload** your Excel (`.xlsx`).
3. Click **Test** to validate:
   - Header normalization (FR/EN aliases).
   - Required columns check.
   - References/UoM/locations exist.
4. Review the **Test report**; fix errors in your file.
5. Click **Import** to apply changes.

> The **Import Center** also shows a recommended order (Categories → Raw Materials → Semi-finished/Fabricated → Finished → BoMs).

---

## 📑 Excel Templates

Headers are **lenient** and accept French/English aliases. Below are representative columns you can use.

### 1) Product Categories (`product.category`)
| column | examples |
|---|---|
| `path` | `Matières premières/Acier`, `Production/Livraison` |
| `code` | `CAT-RAW-001` |

### 2) Products (`product.template` / `product.product`)
| column | examples | notes |
|---|---|---|
| `name` | `Panneau Acier 2mm` | required |
| `default_code` | `RAW-STEEL-2MM` | recommended unique |
| `barcode` | `1234567890123` | optional |
| `category` | `Matières premières/Acier` | creates tree if needed |
| `uom` | `Units` | must exist |
| `type_metier` | `matière première` · `semi-fini` · `fini` | sets `product_type_cm` |

### 3) BoMs — Fabricated / Semi-finished (`mrp.bom`)
**BOM header** (per product):
- `bom_product_name` · `bom_code` · `bom_qty` · `bom_uom` · `bom_type`

**BOM line** (per component):
- `component_name` · `component_qty` · `component_uom`

### 4) BoMs — Finished (`mrp.bom`)
Same structure as above but targeted to finished goods.

### 5) Stock Locations (`stock.location`)
| column | accepted values |
|---|---|
| `name` | `WH/Stock`, `Fabrication`, `Transit` |
| `usage` | `internal`, `view`, `supplier`, `customer`, `inventory`, `production`, `transit` |

> The wizard includes **header aliases** such as: _Quantité composant / Qté composant_, _Unité composant / UoM composant_, etc.

---

## 🧪 Validation & Matching

- **Two-step:** Test (no write) → Import (transactional writes).
- **Header normalization:** French/English synonyms mapped to canonical names.
- **Reference checks:** UoM, locations, product/category references verified.
- **Clear errors:** row number + column + reason, to speed up fixes.

---

## 🔐 Access Rights

Security rules and access are delivered via:
- `security/ir.model.access.csv` (wizard access)
- Menu items and actions under `views/menus_actions.xml`.

---

## 🩺 Troubleshooting

- **`openpyxl` missing** → `pip install openpyxl` on your Odoo Python environment.
- **UoM or Location not found** → pre-create or align spelling.
- **Unknown product/category in BoM** → import categories & products first.
- **Encoding issues** → ensure the file is real Excel (`.xlsx`), not CSV renamed.

---

## 🧠 Technical Notes

- Adds **`product_type_cm`** on `product.template` and `product.product` (related & stored on variant).
- Wizard models: `cm.import.center`, `cm.import.wizard`, `cm.master.import.wizard`.
- Views: `views/import_center_views.xml`, `views/import_wizard_views.xml`, menus in `views/menus_actions.xml`.
- Data: default categories in `data/product_category_data.xml`.

---

## 📜 License

**LGPL-3** — see the module header.

---

> Built with ❤️ by **Rida Louchachha**.
