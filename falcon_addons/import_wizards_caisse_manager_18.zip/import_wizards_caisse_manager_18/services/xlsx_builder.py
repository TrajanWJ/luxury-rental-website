# -*- coding: utf-8 -*-
from odoo import _
from . import constants as C


def parse_worksheet_strict(ws, target_key):
    rows = []
    for row in ws.iter_rows(values_only=True):
        rows.append([("" if v is None else str(v).strip()) for v in row])
    if not rows:
        return {}, []

    raw_header = [h if h is not None else "" for h in rows[0]]

    expected_pairs = C.HEADER_LABELS.get(target_key, [])
    expected_labels = [lbl for (_k, lbl) in expected_pairs]

    while raw_header and (raw_header[-1] or "").strip() == "":
        raw_header.pop()

    if len(raw_header) != len(expected_labels):
        raise ValueError(
            _("Sheet '%(sheet)s' header mismatch.\nExpected exactly %(exp_n)d columns: %(exp)s\n"
              "But found %(got_n)d columns: %(got)s\n\nHeaders cannot be renamed, moved, added or removed."
              ) % {
                "sheet": ws.title,
                "exp_n": len(expected_labels),
                "exp": ", ".join(expected_labels),
                "got_n": len(raw_header),
                "got": ", ".join(raw_header) or "-",
            }
        )

    for i, (got, want) in enumerate(zip(raw_header, expected_labels), start=1):
        if (got or "").strip() != want:
            raise ValueError(
                _("Sheet '%(sheet)s' header mismatch at column %(col)d.\n"
                  "Expected: '%(want)s'\nFound:    '%(got)s'\n\nHeaders cannot be renamed, moved, added or removed."
                  ) % {"sheet": ws.title, "col": i, "want": want, "got": got}
            )

    hmap = {key: idx for idx, (key, _lbl) in enumerate(expected_pairs)}
    body = rows[1:]
    return hmap, body


def build_master_template(env):
    """
    Returns (filename, bytes)
    """
    import io
    output = io.BytesIO()

    try:
        import xlsxwriter
        use_xlsxwriter = True
    except Exception:
        use_xlsxwriter = False

    Uom = env["uom.uom"]
    PP = env["product.product"]
    Cat = env["product.category"]
    Loc = env["stock.location"]

    def _dedup(seq):
        seen = set(); out = []
        for x in seq:
            if x not in seen:
                out.append(x); seen.add(x)
        return out

    uom_names = _dedup(Uom.search([]).mapped("name"))
    existing_categories = _dedup(Cat.search([]).mapped("name"))
    purchasable_variants = _dedup(PP.search([("purchase_ok", "=", True)]).mapped("name"))
    pos_finished_variants = _dedup(PP.search([("product_tmpl_id.available_in_pos", "=", True)]).mapped("name"))

    semi_cat_rec = env.ref("import_wizards_caisse_manager_18.category_semi_finished_cm", raise_if_not_found=False)
    semi_cat_name = semi_cat_rec.name if semi_cat_rec else "Produits semi-finis"
    if semi_cat_name and semi_cat_name not in existing_categories:
        existing_categories = [semi_cat_name] + existing_categories

    parent_loc_names = _dedup(Loc.search([]).mapped("name"))
    if "WH" not in parent_loc_names:
        parent_loc_names = ["WH"] + parent_loc_names
    else:
        parent_loc_names = ["WH"] + [n for n in parent_loc_names if n != "WH"]

    semi_finished_variants = _dedup(PP.search([("product_tmpl_id.product_type_cm", "=", "semi")]).mapped("name"))
    raw_variants = _dedup(PP.search([("product_tmpl_id.product_type_cm", "=", "raw")]).mapped("name"))

    MAX_ROWS = 10000

    if use_xlsxwriter:
        import xlsxwriter
        wb = xlsxwriter.Workbook(output, {'in_memory': True})
        fmt_header_locked = wb.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True, 'locked': True})
        fmt_locked = wb.add_format({'locked': True})
        fmt_unlocked = wb.add_format({'locked': False})
        fmt_unlocked_center = wb.add_format({'locked': False, 'align': 'center', 'valign': 'vcenter'})
        border_unlocked = wb.add_format({'border': 1, 'locked': False})
        colname = xlsxwriter.utility.xl_col_to_name

        def _helper_fill_column(ws, col_idx_zero, values):
            for r, v in enumerate(values, start=1):
                ws.write(r, col_idx_zero, v, fmt_locked)
            ws.set_column(col_idx_zero, col_idx_zero, None, fmt_locked, {'hidden': True})

        def _build_sheet(sheet_key):
            title = C.SHEET_TITLES[sheet_key]
            headers = C.HEADER_LABELS.get(sheet_key, [])
            ws = wb.add_worksheet(title)

            ws.set_column(0, 50, 28, fmt_unlocked)

            if sheet_key not in ("mrp.bom.semi_finished", "mrp.bom.finished"):
                ws.protect('cm', {
                    'select_locked_cells': False,
                    'select_unlocked_cells': True,
                    'format_cells': True,
                    'insert_rows': True,
                    'delete_rows': True,
                    'format_rows': True,
                    'format_columns': True,
                })

            for c, (_k, lbl) in enumerate(headers):
                ws.write(0, c, lbl, fmt_header_locked)
                ws.set_column(c, c, 28, fmt_unlocked)

            next_hcol = len(headers)

            u0 = uom_names[0] if uom_names else ""
            if sheet_key == "product.category":
                for c, v in enumerate(["Catégorie A", ""]):
                    ws.write(1, c, v)

                existing_n = len(existing_categories)
                _helper_fill_column(ws, next_hcol, existing_categories)
                for j in range(1, MAX_ROWS + 1):
                    ws.write_formula(existing_n + j, next_hcol, f"=$A${j + 1}")

                if existing_n or MAX_ROWS:
                    ws.data_validation(1, 1, MAX_ROWS, 1, {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
                        'ignore_blank': True, 'error_type': 'stop',
                        'error_title': 'Parent invalide',
                        'error_message': "Choisissez une catégorie parente de la liste.",
                    })
                return ws

            if sheet_key in ("product.raw", "product.semi_finished", "product.finished"):
                if sheet_key == "product.semi_finished":
                    cat_default = semi_cat_name or (existing_categories[0] if existing_categories else "")
                else:
                    cat_default = existing_categories[0] if existing_categories else ""
                for c, v in enumerate(["Produit A", u0, "199.99", cat_default]):
                    ws.write(1, c, v)

                if uom_names:
                    _helper_fill_column(ws, next_hcol, uom_names)
                    ws.data_validation(1, 1, MAX_ROWS, 1, {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${len(uom_names)}",
                        'ignore_blank': False, 'error_type': 'stop',
                        'error_title': 'Unité invalide',
                        'error_message': "Choisissez l'unité depuis la liste.",
                    })
                next_hcol += 1

                cat_sheet = C.SHEET_TITLES["product.category"]
                existing_n = len(existing_categories)
                _helper_fill_column(ws, next_hcol, existing_categories)
                for j in range(1, MAX_ROWS + 1):
                    ws.write_formula(existing_n + j, next_hcol, f"='{cat_sheet}'!$A${j + 1}")

                ws.data_validation(1, 3, MAX_ROWS, 3, {
                    'validate': 'list',
                    'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
                    'ignore_blank': True, 'error_type': 'stop',
                    'error_title': 'Catégorie invalide',
                    'error_message': "Choisissez une catégorie depuis la liste.",
                })
                return ws

            if sheet_key == "mrp.bom.semi_finished":
                COMPONENT_ROWS_DEFAULT = 10
                BLOCK_ROWS = 1 + COMPONENT_ROWS_DEFAULT
                START_ROW = 1
                p0 = (semi_finished_variants[0] if semi_finished_variants else "Produit semi-fini A")
                u0 = (uom_names[0] if uom_names else "")
                comp0 = raw_variants[0] if raw_variants else "Matière Première A"
                example = [p0, "BOM-001", "1", u0, "normal", comp0, "2", u0]
                for c, v in enumerate(example):
                    ws.write(START_ROW, c, v, fmt_unlocked)

                if uom_names:
                    _helper_fill_column(ws, next_hcol, uom_names)
                    ucol = next_hcol
                    for col_idx in (3, 7):
                        ws.data_validation(
                            START_ROW, col_idx, START_ROW + BLOCK_ROWS - 1, col_idx,
                            {
                                'validate': 'list',
                                'source': f"${colname(ucol)}$1:${colname(ucol)}${len(uom_names)}",
                                'ignore_blank': False, 'error_type': 'stop',
                                'error_title': 'Unité invalide',
                                'error_message': "Choisissez l'unité depuis la liste.",
                            }
                        )
                    next_hcol += 1

                semi_sheet = C.SHEET_TITLES["product.semi_finished"]
                existing_n = len(semi_finished_variants)
                _helper_fill_column(ws, next_hcol, semi_finished_variants)
                for j in range(1, MAX_ROWS + 1):
                    ws.write_formula(existing_n + j, next_hcol, f"='{semi_sheet}'!$A${j + 1}")

                ws.data_validation(
                    START_ROW, 0, START_ROW, 0,
                    {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${max(1, existing_n + MAX_ROWS)}",
                        'ignore_blank': False, 'error_type': 'stop',
                        'error_title': 'Produit invalide',
                        'error_message': "Choisissez un produit semi-fini existant (ou ajoutez-le dans 'Produits – Semi-finis').",
                    }
                )
                next_hcol += 1

                raw_sheet = C.SHEET_TITLES["product.raw"]
                existing_n = len(purchasable_variants)
                _helper_fill_column(ws, next_hcol, purchasable_variants)
                for j in range(1, MAX_ROWS + 1):
                    ws.write_formula(existing_n + j, next_hcol, f"='{raw_sheet}'!$A${j + 1}")

                ws.data_validation(
                    START_ROW, 5, START_ROW + BLOCK_ROWS - 1, 5,
                    {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
                        'ignore_blank': False, 'error_type': 'stop',
                        'error_title': 'Composant invalide',
                        'error_message': "Choisissez une MP (feuille 'Produits – MP' ou article achetable existant).",
                    }
                )
                next_hcol += 1

                ws.set_column(4, 4, None, fmt_unlocked, {'hidden': True})
                ws.write(START_ROW, 4, "normal", fmt_unlocked)

                ws.merge_range(START_ROW, 0, START_ROW + BLOCK_ROWS - 1, 0, example[0], fmt_unlocked_center)
                ws.merge_range(START_ROW, 1, START_ROW + BLOCK_ROWS - 1, 1, example[1], fmt_unlocked_center)
                ws.merge_range(START_ROW, 2, START_ROW + BLOCK_ROWS - 1, 2, example[2], fmt_unlocked_center)
                ws.merge_range(START_ROW, 3, START_ROW + BLOCK_ROWS - 1, 3, example[3], fmt_unlocked_center)

                ws.freeze_panes(1, 0)
                for r in range(START_ROW, START_ROW + BLOCK_ROWS):
                    for c in range(0, 8):
                        if r == START_ROW and c < 5:
                            continue
                        ws.write_blank(r, c, None, border_unlocked)

                ws.write(START_ROW + BLOCK_ROWS, 0,
                         "Astuce : insérez/supprimez des lignes à l’intérieur du bloc pour ajuster le nombre de composants ; "
                         "les cellules fusionnées et les validations s’adaptent.",
                         wb.add_format({'italic': True}))
                return ws

            if sheet_key == "mrp.bom.finished":
                COMPONENT_ROWS_DEFAULT = 10
                BLOCK_ROWS = 1 + COMPONENT_ROWS_DEFAULT
                START_ROW = 1
                p0 = (pos_finished_variants[0] if pos_finished_variants else "Produit fini POS A")
                u0 = (uom_names[0] if uom_names else "")
                comp0 = raw_variants[0] if raw_variants else "Composant A"
                example = [p0, "BOM-001", "1", u0, "phantom", comp0, "2", u0]
                for c, v in enumerate(example):
                    ws.write(START_ROW, c, v, fmt_unlocked)

                if uom_names:
                    _helper_fill_column(ws, next_hcol, uom_names)
                    ucol = next_hcol
                    for col_idx in (3, 7):
                        ws.data_validation(
                            START_ROW, col_idx, START_ROW + BLOCK_ROWS - 1, col_idx,
                            {
                                'validate': 'list',
                                'source': f"${colname(ucol)}$1:${colname(ucol)}${len(uom_names)}",
                                'ignore_blank': False, 'error_type': 'stop',
                                'error_title': 'Unité invalide',
                                'error_message': "Choisissez l'unité depuis la liste.",
                            }
                        )
                    next_hcol += 1

                _helper_fill_column(ws, next_hcol, pos_finished_variants)
                ws.data_validation(
                    START_ROW, 0, START_ROW, 0,
                    {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${max(1, len(pos_finished_variants))}",
                        'ignore_blank': False, 'error_type': 'stop',
                        'error_title': 'Produit fini invalide',
                        'error_message': "Choisissez un produit fini PoS existant (vendu en PoS).",
                    }
                )
                next_hcol += 1

                raw_sheet = C.SHEET_TITLES["product.raw"]
                existing_n = len(purchasable_variants)
                _helper_fill_column(ws, next_hcol, purchasable_variants)
                for j in range(1, MAX_ROWS + 1):
                    ws.write_formula(existing_n + j, next_hcol, f"='{raw_sheet}'!$A${j + 1}")

                ws.data_validation(
                    START_ROW, 5, START_ROW + BLOCK_ROWS - 1, 5,
                    {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
                        'ignore_blank': False, 'error_type': 'stop',
                        'error_title': 'Composant invalide',
                        'error_message': "Choisissez une MP (feuille 'Produits – MP' ou article achetable existant).",
                    }
                )
                next_hcol += 1

                ws.set_column(4, 4, None, fmt_unlocked, {'hidden': True})
                ws.write(START_ROW, 4, "phantom", fmt_unlocked)

                ws.merge_range(START_ROW, 0, START_ROW + BLOCK_ROWS - 1, 0, example[0], fmt_unlocked_center)
                ws.merge_range(START_ROW, 1, START_ROW + BLOCK_ROWS - 1, 1, example[1], fmt_unlocked_center)
                ws.merge_range(START_ROW, 2, START_ROW + BLOCK_ROWS - 1, 2, example[2], fmt_unlocked_center)
                ws.merge_range(START_ROW, 3, START_ROW + BLOCK_ROWS - 1, 3, example[3], fmt_unlocked_center)

                ws.freeze_panes(1, 0)
                for r in range(START_ROW, START_ROW + BLOCK_ROWS):
                    for c in range(0, 8):
                        if r == START_ROW and c < 5:
                            continue
                        ws.write_blank(r, c, None, border_unlocked)

                ws.write(START_ROW + BLOCK_ROWS, 0,
                         "Astuce : insérez/supprimez des lignes à l’intérieur du bloc pour ajuster le nombre de composants ; "
                         "les cellules fusionnées et validations s’adaptent.",
                         wb.add_format({'italic': True}))
                return ws

            if sheet_key == "stock.location":
                for c, v in enumerate(["Test", "WH", "internal"]):
                    ws.write(1, c, v)

                if parent_loc_names:
                    _helper_fill_column(ws, next_hcol, parent_loc_names)
                    ws.data_validation(1, 1, MAX_ROWS, 1, {
                        'validate': 'list',
                        'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${len(parent_loc_names)}",
                        'ignore_blank': True, 'error_type': 'stop',
                        'error_title': 'Parent invalide',
                        'error_message': 'Choisissez un parent de la liste.',
                    })
                    next_hcol += 1

                ws.data_validation(1, 2, MAX_ROWS, 2, {
                    'validate': 'list',
                    'source': C.USAGE_CHOICES,
                    'ignore_blank': False, 'error_type': 'stop',
                    'error_title': 'Type invalide',
                    'error_message': 'Choisissez un type de la liste.',
                })
                return ws

        for key in C.SHEET_IMPORT_ORDER:
            _build_sheet(key)
        wb.close()

    else:
        # Minimal openpyxl fallback (no validations)
        from openpyxl import Workbook
        from openpyxl.utils import get_column_letter

        wb = Workbook()
        first = True
        for key in C.SHEET_IMPORT_ORDER:
            if first:
                ws = wb.active; ws.title = C.SHEET_TITLES[key]; first = False
            else:
                ws = wb.create_sheet(C.SHEET_TITLES[key])
            headers = C.HEADER_LABELS.get(key, [])
            for c, (_k, lbl) in enumerate(headers, start=1):
                ws.cell(row=1, column=c, value=lbl)
                ws.column_dimensions[get_column_letter(c)].width = 28
            if key == "product.category":
                ex = ["Catégorie A", ""]
            elif key in ("product.raw", "product.semi_finished", "product.finished"):
                u0 = uom_names[0] if uom_names else ""
                if key == "product.semi_finished":
                    c_default = semi_cat_name or (existing_categories[0] if existing_categories else "")
                else:
                    c_default = existing_categories[0] if existing_categories else ""
                ex = ["Produit A", u0, "199.99", c_default]
            elif key == "mrp.bom.semi_finished":
                u0 = uom_names[0] if uom_names else ""
                p0 = semi_finished_variants[0] if semi_finished_variants else "Produit Semi-fini A"
                comp0 = raw_variants[0] if raw_variants else "Matière Première A"
                ex = [p0, "BOM-001", "1", u0, "normal", comp0, "2", u0]
            elif key == "mrp.bom.finished":
                u0 = uom_names[0] if uom_names else ""
                ex = ["Produit Fini A", "BOM-001", "1", u0, "phantom", "Composant A", "2", u0]
            else:
                ex = ["Test", "WH", "internal"]
            for c, v in enumerate(ex, start=1):
                ws.cell(row=2, column=c, value=v)

        wb.save(output)

    content = output.getvalue()
    output.close()
    return "Modele_Master_Import.xlsx", content
