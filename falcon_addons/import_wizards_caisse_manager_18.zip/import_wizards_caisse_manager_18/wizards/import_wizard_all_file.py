# # -*- coding: utf-8 -*-
# import base64
# from io import BytesIO
# from odoo import api, fields, models, _
# from odoo.exceptions import UserError, ValidationError
# from odoo.osv import expression
# import unicodedata
#
# try:
#     from openpyxl import load_workbook
# except Exception:
#     load_workbook = None
#
#
# # -------------------- Constants / Labels / Aliases --------------------
#
# USAGE_CHOICES = ["internal", "view", "supplier", "customer", "inventory", "production", "transit"]
# USAGE_FR_TO_CANON = {
#     "interne": "internal",
#     "vue": "view",
#     "fournisseur": "supplier",
#     "client": "customer",
#     "inventaire": "inventory",
#     "production": "production",
#     "transit": "transit",
# }
# BOM_TYPE_CHOICES = ["normal", "phantom", "subcontracting"]
# BOM_TYPES = set(BOM_TYPE_CHOICES)
#
# HEADER_LABELS = {
#     # 1) Categories
#     "product.category": [
#         ("name", "Nom de la catégorie"),
#         ("parent_name", "Catégorie parente"),
#     ],
#
#     # 2) Raw materials
#     "product.raw": [
#         ("name", "Nom du produit"),
#         ("uom_name", "Unité"),
#         ("list_price", "Prix"),
#         ("category_name", "Catégorie"),
#     ],
#
#     # 2.5) Semi-finished / fabricated products
#     "product.semi_finished": [
#         ("name", "Nom du produit"),
#         ("uom_name", "Unité"),
#         ("list_price", "Prix"),
#         ("category_name", "Catégorie"),
#     ],
#
#     # 3) Finished products
#     # "product.finished": [
#     #     ("name", "Nom du produit"),
#     #     ("uom_name", "Unité"),
#     #     ("list_price", "Prix"),
#     #     ("category_name", "Catégorie"),
#     # ],
#
#     # 4) BOM for fabricated (semi-finished) products (Type is hidden in template; import forces phantom)
#     "mrp.bom.semi_finished": [
#         ("bom_product_name", "Produit fabriqué (nom)"),
#         ("bom_code", "Code nomenclature"),
#         ("bom_qty", "Quantité nomenclature (sortie)"),
#         ("bom_uom", "Unité nomenclature"),
#         ("bom_type", "Type de nomenclature (normal/phantom/subcontracting)"),
#         ("component_name", "Nom composant"),
#         ("component_qty", "Quantité composant"),
#         ("component_uom", "Unité composant"),
#     ],
#
#     # (Optional) BOM for finished products
#     "mrp.bom.finished": [
#         ("bom_product_name", "Produit fini (nom)"),
#         ("bom_code", "Code nomenclature"),
#         ("bom_qty", "Quantité nomenclature (sortie)"),
#         ("bom_uom", "Unité nomenclature"),
#         ("bom_type", "Type de nomenclature (normal/phantom/subcontracting)"),
#         ("component_name", "Nom composant"),
#         ("component_qty", "Quantité composant"),
#         ("component_uom", "Unité composant"),
#     ],
#
#     # 5) Locations
#     "stock.location": [
#         ("name", "Nom de l’emplacement"),
#         ("parent_name", "Emplacement parent"),
#         ("usage", "Type (internal/view/fournisseur/client/inventory/production/transit)"),
#     ],
# }
#
# HEADER_ALIASES = {
#     "product.category": {
#         "name": ["Nom de la catégorie", "Catégorie"],
#         "parent_name": ["Catégorie parente", "Parent"],
#     },
#     "product.raw": {
#         "name": ["Nom du produit"],
#         "uom_name": ["Unité", "UoM", "Unité de mesure"],
#         "list_price": ["Prix", "Prix de vente", "Tarif public"],
#         "category_name": ["Catégorie", "Catégorie produit"],
#     },
#     "product.semi_finished": {
#         "name": ["Nom du produit", "Nom produit fabriqué", "Nom semi-fini"],
#         "uom_name": ["Unité", "UoM", "Unité de mesure"],
#         "list_price": ["Prix", "Prix de vente"],
#         "category_name": ["Catégorie", "Catégorie produit"],
#     },
#     # "product.finished": {
#     #     "name": ["Nom du produit", "Nom produit fini"],
#     #     "uom_name": ["Unité", "UoM", "Unité de mesure"],
#     #     "list_price": ["Prix", "Prix de vente"],
#     #     "category_name": ["Catégorie", "Catégorie produit"],
#     # },
#     "mrp.bom.semi_finished": {
#         "bom_product_name": ["Produit fabriqué (nom)", "Nom produit fabriqué", "Produit semi-fini (nom)"],
#         "bom_code": ["Code nomenclature", "Référence nomenclature"],
#         "bom_qty": ["Quantité nomenclature (sortie)", "Qté nomenclature", "Qté BOM"],
#         "bom_uom": ["Unité nomenclature", "UoM nomenclature"],
#         "bom_type": ["Type de nomenclature", "Type BOM"],
#         "component_name": ["Nom composant", "Composant"],
#         "component_qty": ["Quantité composant", "Qté composant"],
#         "component_uom": ["Unité composant", "UoM composant"],
#     },
#     "mrp.bom.finished": {
#         "bom_product_name": ["Produit fini (nom)", "Nom produit fini"],
#         "bom_code": ["Code nomenclature", "Référence nomenclature"],
#         "bom_qty": ["Quantité nomenclature (sortie)", "Qté nomenclature", "Qté BOM"],
#         "bom_uom": ["Unité nomenclature", "UoM nomenclature"],
#         "bom_type": ["Type de nomenclature", "Type BOM"],
#         "component_name": ["Nom composant", "Composant"],
#         "component_qty": ["Quantité composant", "Qté composant"],
#         "component_uom": ["Unité composant", "UoM composant"],
#     },
#     "stock.location": {
#         "name": ["Nom de l’emplacement", "Nom emplacement"],
#         "parent_name": ["Emplacement parent", "Parent"],
#         "usage": ["Usage", "Type", "Type (internal/view/fournisseur/client/inventory/production/transit)"],
#     },
# }
#
# SHEET_TITLES = {
#     "product.category": "Catégories",
#     "product.raw": "Produits – MP",
#     "product.semi_finished": "Produits – Semi-finis",
#     # "product.finished": "Produits – Finis",
#     "mrp.bom.semi_finished": "Nomenclatures – Semi-finis",
#     "mrp.bom.finished": "Nomenclatures – Finis",
#     "stock.location": "Emplacements",
# }
#
# # Import in dependency order
# SHEET_IMPORT_ORDER = [
#     "product.category",
#     "product.raw",
#     "product.semi_finished",
#     # "product.finished",
#     "mrp.bom.semi_finished",
#     "mrp.bom.finished",
#     "stock.location",
# ]
#
#
# # -------------------- Wizard --------------------
#
# class CmMasterImportWizard(models.TransientModel):
#     _name = "cm.master.import.wizard"
#     _description = "Master Import Wizard (All-in-One XLSX)"
#
#     file = fields.Binary("Excel (.xlsx)", required=False)
#     filename = fields.Char()
#     log_text = fields.Text(readonly=True)
#     line_count = fields.Integer(readonly=True)
#     error_count = fields.Integer(readonly=True)
#     tested_ok = fields.Boolean(readonly=True)
#
#     # ---------- action to open this wizard ----------
#     @api.model
#     def action_open_master_wizard(self):
#         """Use this method from a menu or button (XML) to open the wizard."""
#         wiz = self.create({})
#         return {
#             "type": "ir.actions.act_window",
#             "res_model": self._name,
#             "res_id": wiz.id,
#             "view_mode": "form",
#             "target": "new",
#         }
#
#     # ---------- base helpers ----------
#     def _require_openpyxl(self):
#         if load_workbook is None:
#             raise UserError(_("Missing Python dependency: openpyxl"))
#
#     def _read_workbook(self):
#         self._require_openpyxl()
#         if not self.file:
#             raise UserError(_("Please upload an .xlsx file."))
#         try:
#             stream = BytesIO(base64.b64decode(self.file))
#             wb = load_workbook(stream, read_only=True, data_only=True)
#             return wb
#         except Exception as e:
#             raise UserError(_("Could not read file: %s") % e)
#
#     def _log(self, buf, line=None, msg=""):
#         text = f"Line {line}: {msg}" if line is not None else msg
#         buf.append(text)
#
#     def _slug(self, s):
#         if not s:
#             return ""
#         s = unicodedata.normalize("NFKD", s)
#         s = "".join(ch for ch in s if not unicodedata.combining(ch))
#         s = s.lower()
#         for ch in (" ", "_", ".", "-", "’", "'"):
#             s = s.replace(ch, "")
#         return s
#
#     def _alias_map(self, target):
#         amap = {}
#         for canon, _label in HEADER_LABELS.get(target, []):
#             amap[self._slug(canon)] = canon
#         for canon, aliases in HEADER_ALIASES.get(target, {}).items():
#             for a in aliases:
#                 amap[self._slug(a)] = canon
#         for canon, label in HEADER_LABELS.get(target, []):
#             amap[self._slug(label)] = canon
#         return amap
#
#     def _required_cols(self, target):
#         if target == "product.category":
#             return ["name"]
#         if target in ("product.raw", "product.semi_finished", "product.finished"):
#             return ["name", "uom_name"]
#         if target in ("mrp.bom.semi_finished", "mrp.bom.finished"):
#             return ["bom_product_name", "component_name", "component_qty"]
#         if target == "stock.location":
#             return ["name", "usage"]
#         return []
#
#     def _build_header_index(self, header_cells, target):
#         amap = self._alias_map(target)
#         hmap, unknown = {}, []
#         for idx, raw in enumerate(header_cells):
#             key = amap.get(self._slug(raw or ""))
#             if key and key not in hmap:
#                 hmap[key] = idx
#             elif not key:
#                 unknown.append(raw or "")
#         required = self._required_cols(target)
#         missing = [k for k in required if k not in hmap]
#         return hmap, missing, unknown
#
#     def _col_by_key(self, hmap, row, key):
#         idx = hmap.get(key)
#         if idx is None or idx >= len(row):
#             return ""
#         return row[idx]
#
#     def _map_usage_canonical(self, value):
#         v = (value or "").strip().lower()
#         if v in USAGE_CHOICES:
#             return v
#         return USAGE_FR_TO_CANON.get(v, v)
#
#     def _norm(self, s):
#         return (s or "").strip().casefold()
#
#     def _collect_bom_rows(self, hmap, body, idx_start, buf):
#         """
#         Carry-forward for BOM header fields (A–D) so users can leave them blank on subsequent lines.
#
#         We collect/validate ONLY rows that have a component_name.
#         - Fully empty row .......................... skip
#         - Row with any A–D but no F–H ............. header-only -> refresh context, skip
#         - Row with qty/uom but NO component name ... skip
#         """
#         records = []
#         ctx = {"bom_product_name": "", "bom_code": "", "bom_qty": "1", "bom_uom": ""}
#
#         for i, row in enumerate(body, start=idx_start):
#             def raw(k):
#                 return (self._col_by_key(hmap, row, k) or "").strip()
#
#             bp, bcd, bqt, bu = raw("bom_product_name"), raw("bom_code"), raw("bom_qty"), raw("bom_uom")
#             cn, cq, cu = raw("component_name"), raw("component_qty"), raw("component_uom")
#
#             # 1) fully empty
#             if not (bp or bcd or bqt or bu or cn or cq or cu):
#                 continue
#
#             # 2) update carry-forward if any header appears
#             if bp or bcd or bqt or bu:
#                 ctx = {
#                     "bom_product_name": bp or ctx["bom_product_name"],
#                     "bom_code": bcd or ctx["bom_code"],
#                     "bom_qty": bqt or ctx["bom_qty"],
#                     "bom_uom": bu or ctx["bom_uom"],
#                 }
#
#             # 3) header-only line (no component fields at all)
#             if not (cn or cq or cu):
#                 continue
#
#             # 4) component line must have a name; otherwise skip quietly
#             if not cn:
#                 continue
#
#             vals = {
#                 "bom_product_name": ctx["bom_product_name"],
#                 "bom_code": ctx["bom_code"],
#                 "bom_qty": ctx["bom_qty"],
#                 "bom_uom": ctx["bom_uom"],
#                 "component_name": cn,
#                 "component_qty": cq,
#                 "component_uom": cu,
#             }
#             rec = self._validate_bom_row(hmap={}, row=vals, idx=i, buf=buf)
#             records.append(rec)
#
#         return records
#
#     # ---------- lookups ----------
#     def _uom_by_name(self, name, strict=False):
#         if not name:
#             return False
#         Uom = self.env["uom.uom"]
#         u = Uom.search([("name", "=", name)], limit=1)
#         if not u:
#             u = Uom.search([("name", "ilike", name)], limit=1)
#         if strict and not u:
#             raise ValidationError(_("Unit of Measure not found: %s") % (name or ""))
#         return u
#
#     def _category_by_name(self, name, strict=False):
#         if not name:
#             return False
#         Cat = self.env["product.category"]
#         c = Cat.search([("name", "=", name)], limit=1)
#         if not c:
#             c = Cat.search([("name", "ilike", name)], limit=1)
#         if strict and not c:
#             raise ValidationError(_("Category not found: %s") % (name or ""))
#         return c
#
#     def _product_by_name(self, name, strict=False):
#         Product = self.env["product.product"]
#         p = Product.search([("name", "=", name)], limit=1)
#         if not p:
#             p = Product.search([("name", "ilike", name)], limit=1)
#         if strict and not p:
#             raise ValidationError(_("Product not found: %s") % (name or ""))
#         return p
#
#     def _product_tmpl_by_name(self, name, strict=False):
#         T = self.env["product.template"]
#         t = T.search([("name", "=", name)], limit=1)
#         if not t:
#             t = T.search([("name", "ilike", name)], limit=1)
#         if strict and not t:
#             raise ValidationError(_("Product template not found: %s") % (name or ""))
#         return t
#
#     # ---------- validators ----------
#     def _validate_category(self, hmap, row, idx, buf):
#         col = lambda k: self._col_by_key(hmap, row, k)
#         name = col("name")
#         parent_name = col("parent_name") or ""
#         if not name:
#             self._log(buf, idx, _("Missing category name"))
#         return {"name": name, "parent_name": parent_name}
#
#     def _validate_product_generic(self, hmap, row, idx, buf):
#         col = lambda k: self._col_by_key(hmap, row, k)
#         name = col("name")
#         uom_name = col("uom_name")
#         price_raw = col("list_price") or ""
#         cat_name = col("category_name") or ""
#
#         if not name:
#             self._log(buf, idx, _("Missing product Name"))
#         if not uom_name:
#             self._log(buf, idx, _("Missing product Unit (Unité)"))
#
#         # Default price parsing
#         list_price = 0.0
#         if price_raw != "":
#             try:
#                 list_price = float(price_raw)
#             except Exception:
#                 self._log(buf, idx, _("Invalid Price"))
#
#         # --- NEW: UoM compatibility against existing product/template (if any) ---
#         if name and uom_name:
#             # UoM entered in the sheet
#             try:
#                 sheet_uom = self._uom_by_name(uom_name, strict=True)
#             except Exception:
#                 # _uom_by_name(strict=True) already raises a nice error elsewhere,
#                 # but keep a log line to tag the row in test mode.
#                 self._log(buf, idx, _("Unknown Unit of Measure: %s") % uom_name)
#                 sheet_uom = False
#
#             # If product already exists, check UoM category compatibility
#             try:
#                 tmpl = self._product_tmpl_by_name(name, strict=False)
#                 if tmpl and sheet_uom:
#                     db_cat = tmpl.uom_id.category_id
#                     in_cat = sheet_uom.category_id
#                     if db_cat and in_cat and db_cat.id != in_cat.id:
#                         self._log(
#                             buf, idx,
#                             _("UoM '%(uom)s' is incompatible with existing product '%(prod)s' UoM '%(dbuom)s' "
#                               "(different categories: %(c1)s vs %(c2)s)") % {
#                                 "uom": sheet_uom.name,
#                                 "prod": tmpl.display_name,
#                                 "dbuom": tmpl.uom_id.name,
#                                 "c1": in_cat.display_name or in_cat.name,
#                                 "c2": db_cat.display_name or db_cat.name,
#                             }
#                         )
#             except Exception:
#                 pass
#
#         return {
#             "name": name,
#             "uom_name": uom_name,
#             "list_price": list_price,
#             "category_name": cat_name,
#         }
#
#     def _validate_location(self, hmap, row, idx, buf):
#         col = lambda k: self._col_by_key(hmap, row, k)
#         name = col("name")
#         usage = self._map_usage_canonical(col("usage"))
#         parent_name = col("parent_name") or ""
#         if not name:
#             self._log(buf, idx, _("Missing Location Name"))
#         if usage not in USAGE_CHOICES:
#             self._log(buf, idx, _("Invalid Type (internal/view/supplier/customer/inventory/production/transit)"))
#         return {"name": name, "usage": usage or "internal", "parent_name": parent_name}
#
#     def _validate_bom_row(self, hmap, row, idx, buf):
#         if isinstance(row, dict):
#             col = lambda k: (row.get(k) or "").strip()
#         else:
#             col = lambda k: (self._col_by_key(hmap, row, k) or "").strip()
#
#         p_name = col("bom_product_name")
#         b_code = col("bom_code") or ""
#         b_qty = col("bom_qty") or "1"
#         b_uom = col("bom_uom") or ""
#         b_type = "normal"
#
#         c_name = col("component_name")
#         c_qty = col("component_qty") or ""
#         c_uom = col("component_uom") or ""
#
#         if not p_name:
#             self._log(buf, idx, _("Missing finished/fabricated product name"))
#
#         # If there's NO component name, don't produce qty errors; let the collector skip these lines.
#         if not c_name:
#             try:
#                 b_qty_f = float(b_qty);
#                 b_qty_f = b_qty_f if b_qty_f > 0 else 1.0
#             except Exception:
#                 b_qty_f = 1.0
#             return {
#                 "bom_product_name": p_name,
#                 "bom_code": b_code,
#                 "bom_qty": b_qty_f,
#                 "bom_uom": b_uom,
#                 "bom_type": b_type,
#                 "component_name": "",
#                 "component_qty": 0.0,
#                 "component_uom": c_uom,
#             }
#
#         # Only now validate component qty
#         try:
#             c_qty_f = float(c_qty)
#             if c_qty_f <= 0:
#                 raise Exception
#         except Exception:
#             self._log(buf, idx, _("Invalid component_qty (must be > 0)"))
#             c_qty_f = 0.0
#
#         try:
#             b_qty_f = float(b_qty)
#             if b_qty_f <= 0:
#                 raise Exception
#         except Exception:
#             self._log(buf, idx, _("Invalid BOM quantity (must be > 0)"))
#             b_qty_f = 1.0
#
#         # UoM compatibility checks (unchanged)
#         if p_name and b_uom:
#             try:
#                 tmpl = self._product_tmpl_by_name(p_name, strict=False)
#                 bom_uom = self._uom_by_name(b_uom, strict=True)
#                 if tmpl and bom_uom:
#                     db_cat = tmpl.uom_id.category_id
#                     in_cat = bom_uom.category_id
#                     if db_cat and in_cat and db_cat.id != in_cat.id:
#                         self._log(
#                             buf, idx,
#                             _("BOM UoM '%(uom)s' is incompatible with semi-finished '%(prod)s' UoM '%(dbuom)s' "
#                               "(different categories: %(c1)s vs %(c2)s). Line %(line)d (columns A–D).") % {
#                                 "uom": bom_uom.name,
#                                 "prod": tmpl.display_name if tmpl else p_name,
#                                 "dbuom": tmpl.uom_id.name if tmpl else "-",
#                                 "c1": in_cat.display_name or in_cat.name,
#                                 "c2": db_cat.display_name or db_cat.name,
#                                 "line": idx,
#                             }
#                         )
#             except Exception:
#                 pass
#
#         if c_name and c_uom:
#             try:
#                 comp = self._product_by_name(c_name, strict=False)
#                 comp_uom_in = self._uom_by_name(c_uom, strict=True)
#                 if comp and comp_uom_in:
#                     db_cat = comp.uom_id.category_id
#                     in_cat = comp_uom_in.category_id
#                     if db_cat and in_cat and db_cat.id != in_cat.id:
#                         self._log(
#                             buf, idx,
#                             _("Component UoM '%(uom)s' is incompatible with component '%(comp)s' UoM '%(dbuom)s' "
#                               "(different categories: %(c1)s vs %(c2)s). Line %(line)d (columns F–H).") % {
#                                 "uom": comp_uom_in.name,
#                                 "comp": comp.display_name if comp else c_name,
#                                 "dbuom": comp.uom_id.name if comp else "-",
#                                 "c1": in_cat.display_name or in_cat.name,
#                                 "c2": db_cat.display_name or db_cat.name,
#                                 "line": idx,
#                             }
#                         )
#             except Exception:
#                 pass
#
#         return {
#             "bom_product_name": p_name,
#             "bom_code": b_code,
#             "bom_qty": b_qty_f,
#             "bom_uom": b_uom,
#             "bom_type": b_type,
#             "component_name": c_name,
#             "component_qty": c_qty_f,
#             "component_uom": c_uom,
#         }
#
#     # ---------- collect ----------
#     def _is_empty_row(self, hmap, row):
#         for idx in hmap.values():
#             if idx is not None and idx < len(row):
#                 if (row[idx] or "").strip():
#                     return False
#         return True
#
#     def _collect(self, hmap, body, target):
#         log, records = [], []
#         if target in ("mrp.bom.semi_finished", "mrp.bom.finished"):
#             records = self._collect_bom_rows(hmap, body, idx_start=2, buf=log)
#             # count lines with any "Line N:" error
#             bad_lines = set()
#             for l in log:
#                 if l.startswith("Line "):
#                     bad_lines.add(l.split(":")[0].split()[-1])
#             return records, log, len(records), len(bad_lines)
#
#         # original logic for non-BOM sheets
#         count_nonempty = 0
#         for i, row in enumerate(body, start=2):
#             if self._is_empty_row(hmap, row):
#                 continue
#             count_nonempty += 1
#             if target == "product.category":
#                 vals = self._validate_category(hmap, row, i, log)
#             elif target in ("product.raw", "product.semi_finished", "product.finished"):
#                 vals = self._validate_product_generic(hmap, row, i, log)
#             elif target == "stock.location":
#                 vals = self._validate_location(hmap, row, i, log)
#             else:
#                 vals = self._validate_bom_row(hmap, row, i, log)
#             records.append(vals)
#
#         bad_lines = set()
#         for l in log:
#             if l.startswith("Line "):
#                 bad_lines.add(l.split(":")[0].split()[-1])
#         return records, log, count_nonempty, len(bad_lines)
#
#     # ---------- resolvers / upserts ----------
#     def _upsert(self, model, domain, create_vals, update_vals=None):
#         rec = self.env[model].search(domain, limit=1)
#         if rec:
#             rec.write(update_vals or create_vals)
#             return rec, "updated"
#         return self.env[model].create(create_vals), "created"
#
#     def _get_or_create_category_by_name(self, name, parent_name=None):
#         Cat = self.env["product.category"]
#         cat = Cat.search([("name", "=", name)], limit=1)
#         if cat:
#             return cat
#         vals = {"name": name}
#         if parent_name:
#             parent = Cat.search([("name", "=", parent_name)], limit=1)
#             if parent:
#                 vals["parent_id"] = parent.id
#         return Cat.create(vals)
#
#     def _default_semi_finished_category(self):
#         cat = self.env.ref(
#             "import_wizards_caisse_manager_18.category_semi_finished_cm",
#             raise_if_not_found=False,
#         )
#         if cat:
#             return cat
#         return self._get_or_create_category_by_name("Produits semi-finis")
#
#     def _resolve_category_vals(self, vals):
#         parent_id = False
#         if vals.get("parent_name"):
#             parent = self._category_by_name(vals["parent_name"], strict=True)
#             parent_id = parent.id
#         return {"name": vals["name"], "parent_id": parent_id or False}
#
#     def _resolve_product_vals(self, vals, target):
#         uom = self._uom_by_name(vals.get("uom_name"), strict=True)
#         provided_cat = self._category_by_name(vals.get("category_name"))
#         if provided_cat:
#             categ = provided_cat
#         elif target == "product.semi_finished":
#             categ = self._default_semi_finished_category()
#         else:
#             categ = self.env.ref("product.product_category_all")
#         base = {
#             "name": vals["name"],
#             "uom_id": uom.id,
#             "uom_po_id": uom.id,
#             "list_price": vals.get("list_price") or 0.0,
#             "categ_id": categ.id,
#             "is_storable": True,
#             "product_type_cm": "raw",
#         }
#         if target == "product.raw":
#             base.update({
#                 "type": "consu",
#                 "purchase_ok": True,
#                 "sale_ok": False,
#                 "product_type_cm": "raw",
#             })
#         elif target == "product.semi_finished":
#             base.update({
#                 "type": "consu",
#                 "purchase_ok": False,
#                 "sale_ok": False,
#                 "product_type_cm": "semi",
#             })
#         else:  # finished
#             base.update({
#                 "type": "consu",
#                 "purchase_ok": False,
#                 "sale_ok": True,
#                 "available_in_pos": True,
#                 "is_storable": True,
#                 "product_type_cm": "finished",
#             })
#         return base
#
#     def _resolve_location_vals(self, vals):
#         parent_id = False
#         if vals.get("parent_name"):
#             parent = self.env["stock.location"].search([("name", "=", vals["parent_name"])], limit=1)
#             if parent:
#                 parent_id = parent.id
#         return {"name": vals["name"], "usage": vals["usage"], "location_id": parent_id, "active": True}
#
#     # ---------- importers ----------
#     def _import_categories(self, rows):
#         created = updated = 0
#         details = []
#         for r in rows:
#             v = self._resolve_category_vals(r)
#             dom = [("name", "=", v["name"])]
#             rec, status = self._upsert("product.category", dom, v)
#             if status == "created":
#                 created += 1
#             else:
#                 updated += 1
#             details.append(f"product.category({rec.id}) {status}")
#         return created, updated, details
#
#     def _import_products(self, rows, target_key):
#         PT = self.env["product.template"]
#         created = updated = 0
#         details = []
#         for r in rows:
#             v = self._resolve_product_vals(r, target_key)
#             rec = PT.search([("name", "=", v["name"])], limit=1)
#             if rec:
#                 rec.write(v)
#                 updated += 1
#                 details.append(f"product.template({rec.id}) updated")
#             else:
#                 rec = PT.create(v)
#                 created += 1
#                 details.append(f"product.template({rec.id}) created")
#         return created, updated, details
#
#     def _import_locations(self, rows):
#         created = updated = 0
#         details = []
#         for r in rows:
#             v = self._resolve_location_vals(r)
#             dom = [("name", "=", v["name"])]
#             if v.get("location_id"):
#                 dom.append(("location_id", "=", v["location_id"]))
#             rec, status = self._upsert("stock.location", dom, v)
#             if status == "created":
#                 created += 1
#             else:
#                 updated += 1
#             details.append(f"stock.location({rec.id}) {status}")
#         return created, updated, details
#
#     def _import_boms_semi_finished(self, rows, allowed_names=None, allowed_components=None):
#         MrpBom = self.env["mrp.bom"]
#         PP = self.env["product.product"]
#         created = updated = 0
#         details = []
#
#         # Group by normalized product + normalized code ('normal' sentinel if empty)
#         grouped = {}
#         for r in rows:
#             pname = self._norm(r.get("bom_product_name"))
#             code = self._norm(r.get("bom_code")) or "normal"
#             key = (pname, code)
#             grouped.setdefault(key, {"head": r, "lines": []})
#             grouped[key]["lines"].append(r)
#
#         # Pre-normalize allowlists once
#         norm_allowed_names = {self._norm(x) for x in (allowed_names or set())} if allowed_names is not None else None
#         norm_allowed_comp = {self._norm(x) for x in
#                              (allowed_components or set())} if allowed_components is not None else None
#
#         for (_pname_norm, _code_norm), pack in grouped.items():
#             head = pack["head"]
#
#             # Original (pretty) values for logging/search
#             bom_prod_name = (head.get("bom_product_name") or "").strip()
#             code_raw = (head.get("bom_code") or "").strip()
#
#             # 1) Restrict semi-fini to the sheet names if provided
#             if norm_allowed_names is not None and self._norm(bom_prod_name) not in norm_allowed_names:
#                 raise ValidationError(
#                     _("Le produit de nomenclature '%s' n’est pas listé dans l’onglet 'Produits – Semi-finis' du fichier.") % (
#                                 bom_prod_name or ""))
#
#             # 2) Locate product/template (no creation)
#             prod = self._product_by_name(bom_prod_name, strict=False)
#             tmpl = prod.product_tmpl_id if prod else self._product_tmpl_by_name(bom_prod_name, strict=True)
#
#             # 3) Enforce semi-fini rule (your rule)
#             if not (tmpl.type == "consu" and not tmpl.sale_ok):
#                 raise ValidationError(
#                     _("Le produit '%s' n'est pas identifié comme 'fabriqué / semi-fini' (type=consu et non vendu).") % tmpl.display_name)
#
#             # 4) Parse qty/uom; force type = normal
#             try:
#                 qty = float(head.get("bom_qty") or 1.0)
#                 if qty <= 0:
#                     qty = 1.0
#             except Exception:
#                 qty = 1.0
#             uom = self._uom_by_name(head.get("bom_uom")) or tmpl.uom_id
#             btype = "normal"
#
#             # 5) Find an existing BOM robustly:
#             #    - match company (current or global)
#             #    - match template OR any variant of that template
#             #    - if code is provided, include it in the domain (case-insensitive compare via exact stored string)
#             domain_base = [
#                 ("type", "=", btype),
#                 ("company_id", "in", [False, self.env.company.id]),
#             ]
#             # candidate variant (any) of the template (used when BoM is variant-level)
#             any_variant = PP.search([("product_tmpl_id", "=", tmpl.id)], limit=1)
#
#             domain_prod = ['|', ("product_tmpl_id", "=", tmpl.id), ("product_id", "=", any_variant.id or 0)]
#             if code_raw:
#                 domain = expression.AND([domain_base, domain_prod, [("code", "=", code_raw)]])
#             else:
#                 domain = expression.AND([domain_base, domain_prod])
#
#             bom = MrpBom.search(domain, limit=1)
#
#             # 6) Create/update the BOM header
#             vals = {
#                 "product_tmpl_id": tmpl.id,
#                 "product_qty": qty,
#                 "product_uom_id": uom.id,
#                 "code": code_raw or False,
#                 "type": btype,
#                 # If you want to pin it to a variant, you could also set product_id here.
#             }
#             if bom:
#                 bom.write(vals)
#                 status = "updated"
#                 updated += 1
#             else:
#                 bom = MrpBom.create(vals)
#                 status = "created"
#                 created += 1
#
#             # 7) Build/replace lines in one write
#             line_vals = []
#             for r in pack["lines"]:
#                 cname = (r.get("component_name") or "").strip()
#                 if norm_allowed_comp is not None and self._norm(cname) not in norm_allowed_comp:
#                     raise ValidationError(
#                         _("Composant '%s' non autorisé. Utilisez une MP existante achetable ou une MP saisie dans 'Produits – MP'.") % cname)
#
#                 comp = self._product_by_name(cname, strict=True)  # variant
#                 comp_uom = self._uom_by_name(r.get("component_uom")) or comp.uom_id
#                 try:
#                     cqty = float(r.get("component_qty") or 0.0)
#                 except Exception:
#                     cqty = 0.0
#                 line_vals.append((0, 0, {
#                     "product_id": comp.id,
#                     "product_qty": cqty,
#                     "product_uom_id": comp_uom.id,
#                 }))
#
#             if line_vals:
#                 bom.write({"bom_line_ids": [(5, 0, 0)] + line_vals})
#
#             details.append(f"mrp.bom({bom.id}) {status} for template {tmpl.display_name} (code={code_raw or '-'})")
#
#         return created, updated, details
#
#     def _import_boms_finished(self, rows, allowed_components=None):
#         MrpBom = self.env["mrp.bom"]
#         PP = self.env["product.product"]
#         created = updated = 0
#         details = []
#
#         # Group by (product, code) so we create/update a single header and many lines
#         grouped = {}
#         for r in rows:
#             key = (r.get("bom_product_name") or "", self._norm(r.get("bom_code") or "phantom"))
#             grouped.setdefault(key, {"head": r, "lines": []})["lines"].append(r)
#
#         norm_allowed_comp = {self._norm(x) for x in
#                              (allowed_components or set())} if allowed_components is not None else None
#
#         for (_pname, _code_norm), pack in grouped.items():
#             head = pack["head"]
#
#             # 1) product must exist AND be PoS-enabled
#             prod = self._product_by_name(head.get("bom_product_name"), strict=True)
#             tmpl = prod.product_tmpl_id
#             if not tmpl.available_in_pos:
#                 raise ValidationError(_("Le produit fini '%s' n'est pas disponible en PoS (available_in_pos=False).")
#                                       % (tmpl.display_name))
#
#             # 2) qty/uom; force type=phantom; preserve code if any
#             try:
#                 qty = float(head.get("bom_qty") or 1.0)
#                 if qty <= 0:
#                     qty = 1.0
#             except Exception:
#                 qty = 1.0
#             uom = self._uom_by_name(head.get("bom_uom")) or tmpl.uom_id
#             btype = "phantom"  # ← fixed here only for FINISHED
#             code = (head.get("bom_code") or "").strip()
#
#             # 3) locate existing BOM robustly (company, template/variant, optional code)
#             domain_base = [("type", "=", btype), ("company_id", "in", [False, self.env.company.id])]
#             any_variant = PP.search([("product_tmpl_id", "=", tmpl.id)], limit=1)
#             domain_prod = ['|', ("product_tmpl_id", "=", tmpl.id), ("product_id", "=", any_variant.id or 0)]
#             domain = expression.AND([domain_base, domain_prod, [("code", "=", code)]]) if code else \
#                 expression.AND([domain_base, domain_prod])
#             bom = MrpBom.search(domain, limit=1)
#
#             vals = {
#                 "product_tmpl_id": tmpl.id,
#                 "product_qty": qty,
#                 "product_uom_id": uom.id,
#                 "code": code or False,
#                 "type": btype,
#             }
#             if bom:
#                 bom.write(vals);
#                 status = "updated";
#                 updated += 1
#             else:
#                 bom = MrpBom.create(vals);
#                 status = "created";
#                 created += 1
#
#             # 4) lines (+ optional allowlist)
#             line_vals = []
#             for r in pack["lines"]:
#                 cname = (r.get("component_name") or "").strip()
#                 if norm_allowed_comp is not None and self._norm(cname) not in norm_allowed_comp:
#                     raise ValidationError(
#                         _("Composant '%s' non autorisé. Utilisez une MP existante achetable ou une MP saisie dans 'Produits – MP'.") % cname)
#                 comp = self._product_by_name(cname, strict=True)
#                 comp_uom = self._uom_by_name(r.get("component_uom")) or comp.uom_id
#                 try:
#                     cqty = float(r.get("component_qty") or 0.0)
#                 except Exception:
#                     cqty = 0.0
#                 line_vals.append((0, 0, {"product_id": comp.id, "product_qty": cqty, "product_uom_id": comp_uom.id}))
#
#             if line_vals:
#                 bom.write({"bom_line_ids": [(5, 0, 0)] + line_vals})
#
#             details.append(f"mrp.bom({bom.id}) {status} for template {tmpl.display_name} (code={code or '-'})")
#
#         return created, updated, details
#
#     # ---------- sheet parsing ----------
#     def _parse_worksheet(self, ws, target_key):
#         """Parse ONE worksheet (first row = header). Returns (hmap, body_rows).
#            STRICT: headers must match exactly the official labels (order + names)."""
#         rows = []
#         for row in ws.iter_rows(values_only=True):
#             rows.append([("" if v is None else str(v).strip()) for v in row])
#         if not rows:
#             return {}, []
#
#         raw_header = [h if h is not None else "" for h in rows[0]]
#
#         # Strict expected labels (exact strings, exact order, exact length)
#         expected_pairs = HEADER_LABELS.get(target_key, [])
#         expected_labels = [lbl for (_k, lbl) in expected_pairs]
#
#         # Remove trailing empty cells users sometimes leave at the end:
#         while raw_header and (raw_header[-1] or "").strip() == "":
#             raw_header.pop()
#
#         if len(raw_header) != len(expected_labels):
#             raise UserError(_(
#                 "Sheet '%(sheet)s' header mismatch.\n"
#                 "Expected exactly %(exp_n)d columns: %(exp)s\n"
#                 "But found %(got_n)d columns: %(got)s\n\n"
#                 "Headers cannot be renamed, moved, added or removed."
#             ) % {
#                                 "sheet": ws.title,
#                                 "exp_n": len(expected_labels),
#                                 "exp": ", ".join(expected_labels),
#                                 "got_n": len(raw_header),
#                                 "got": ", ".join(raw_header) or "-",
#                             })
#
#         for i, (got, want) in enumerate(zip(raw_header, expected_labels), start=1):
#             if (got or "").strip() != want:
#                 raise UserError(_(
#                     "Sheet '%(sheet)s' header mismatch at column %(col)d.\n"
#                     "Expected: '%(want)s'\nFound:    '%(got)s'\n\n"
#                     "Headers cannot be renamed, moved, added or removed."
#                 ) % {"sheet": ws.title, "col": i, "want": want, "got": got})
#
#         # Build hmap by position using canonical keys from HEADER_LABELS
#         hmap = {key: idx for idx, (key, _lbl) in enumerate(expected_pairs)}
#         body = rows[1:]
#         return hmap, body
#
#     # ---------- Actions: Download / Test / Import ----------
#     def action_download_master_template(self):
#         """
#         Build a workbook containing ALL target sheets.
#         No global Lists sheet:
#           - Each sheet hosts its own hidden helper columns.
#           - Product category dropdowns include existing categories + values typed in 'Catégories' sheet.
#           - mrp.bom.semi_finished: hide Type col (E) and force 'phantom' sample value.
#         """
#         self.ensure_one()
#         import io
#         output = io.BytesIO()
#
#         try:
#             import xlsxwriter
#             use_xlsxwriter = True
#         except Exception:
#             use_xlsxwriter = False
#
#         # Preload lists from Odoo
#         Uom = self.env["uom.uom"]
#         PP = self.env["product.product"]
#         Cat = self.env["product.category"]
#         Loc = self.env["stock.location"]
#
#         def _dedup(seq):
#             seen = set()
#             out = []
#             for x in seq:
#                 if x not in seen:
#                     out.append(x);
#                     seen.add(x)
#             return out
#
#         uom_names = _dedup(Uom.search([]).mapped("name"))
#         existing_categories = _dedup(Cat.search([]).mapped("name"))
#         purchasable_variants = _dedup(PP.search([("purchase_ok", "=", True)]).mapped("name"))
#         pos_finished_variants = _dedup(
#             PP.search([("product_tmpl_id.available_in_pos", "=", True)]).mapped("name")
#         )
#
#         semi_cat_rec = self.env.ref(
#             "import_wizards_caisse_manager_18.category_semi_finished_cm",
#             raise_if_not_found=False,
#         )
#         semi_cat_name = semi_cat_rec.name if semi_cat_rec else "Produits semi-finis"
#
#         if semi_cat_name and semi_cat_name not in existing_categories:
#             existing_categories = [semi_cat_name] + existing_categories
#
#         parent_loc_names = _dedup(Loc.search([]).mapped("name"))
#         # make "WH" appear first if present/else prepend (common default)
#         if "WH" not in parent_loc_names:
#             parent_loc_names = ["WH"] + parent_loc_names
#         else:
#             parent_loc_names = ["WH"] + [n for n in parent_loc_names if n != "WH"]
#
#         semi_finished_variants = _dedup(
#             PP.search([("product_tmpl_id.product_type_cm", "=", "semi")]).mapped("name")
#         )
#         raw_variants = _dedup(
#             PP.search([("product_tmpl_id.product_type_cm", "=", "raw")]).mapped("name")
#         )
#
#         MAX_ROWS = 10000
#
#         if use_xlsxwriter:
#             import xlsxwriter
#             wb = xlsxwriter.Workbook(output, {'in_memory': True})
#             fmt_header_locked = wb.add_format({
#                 'bold': True, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True, 'locked': True
#             })
#             fmt_locked = wb.add_format({'locked': True})
#             fmt_unlocked = wb.add_format({'locked': False})
#             # unlocked + centered (for merged header block cells in BOM examples)
#             fmt_unlocked_center = wb.add_format({'locked': False, 'align': 'center', 'valign': 'vcenter'})
#             border_unlocked = wb.add_format({'border': 1, 'locked': False})
#             colname = xlsxwriter.utility.xl_col_to_name
#
#             # helper: write vertical list in a hidden helper column on the SAME sheet
#             def _helper_fill_column(ws, col_idx_zero, values):
#                 for r, v in enumerate(values, start=1):
#                     ws.write(r, col_idx_zero, v, fmt_locked)
#                 ws.set_column(col_idx_zero, col_idx_zero, None, fmt_locked, {'hidden': True})
#
#             def _build_sheet(sheet_key):
#                 title = SHEET_TITLES[sheet_key]
#                 headers = HEADER_LABELS.get(sheet_key, [])
#                 ws = wb.add_worksheet(title)
#
#                 ws.set_column(0, 50, 28, fmt_unlocked)
#
#                 if sheet_key not in ("mrp.bom.semi_finished", "mrp.bom.finished"):
#                     ws.protect('cm', {
#                         'select_locked_cells': False,
#                         'select_unlocked_cells': True,
#                         'format_cells': True,
#                         'insert_rows': True,
#                         'delete_rows': True,
#                         'format_rows': True,
#                         'format_columns': True,
#                     })
#
#                 # write headers
#                 for c, (_k, lbl) in enumerate(headers):
#                     ws.write(0, c, lbl, fmt_header_locked)
#                     ws.set_column(c, c, 28, fmt_unlocked)
#
#                     # where helper columns start (right after last visible column)
#                 next_hcol = len(headers)
#
#                 # sample values (only for the first data row as illustration)
#                 u0 = uom_names[0] if uom_names else ""
#                 c0 = existing_categories[0] if existing_categories else ""
#
#                 if sheet_key == "product.category":
#                     # Example
#                     for c, v in enumerate(["Catégorie A", ""]):  # Name, Parent
#                         ws.write(1, c, v)
#
#                     # Helper for Parent = existing categories + refs to THIS sheet's typed names (A2..A..)
#                     existing_n = len(existing_categories)
#                     _helper_fill_column(ws, next_hcol, existing_categories)
#                     # append references to same sheet; same-sheet absolute ref avoids quoting issues
#                     for j in range(1, MAX_ROWS + 1):
#                         ws.write_formula(existing_n + j,     next_hcol, f"=$A${j + 1}")
#
#                     # Parent dropdown on column B (index 1) using SAME-SHEET range
#                     if existing_n or MAX_ROWS:
#                         ws.data_validation(1, 1, MAX_ROWS, 1, {
#                             'validate': 'list',
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
#                             'ignore_blank': True, 'error_type': 'stop',
#                             'error_title': 'Parent invalide',
#                             'error_message': "Choisissez une catégorie parente de la liste.",
#                         })
#                     next_hcol += 1
#
#                 elif sheet_key in ("product.raw", "product.semi_finished", "product.finished"):
#                     # Example
#                     if sheet_key == "product.semi_finished":
#                         cat_default = semi_cat_name or (existing_categories[0] if existing_categories else "")
#                     else:
#                         cat_default = existing_categories[0] if existing_categories else ""
#                     for c, v in enumerate(["Produit A", u0, "199.99", cat_default]):
#                         ws.write(1, c, v)
#                     # UoM helper and dropdown (column B index 1)
#                     if uom_names:
#                         _helper_fill_column(ws, next_hcol, uom_names)
#                         ws.data_validation(1, 1, MAX_ROWS, 1, {
#                             'validate': 'list',
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${len(uom_names)}",
#                             'ignore_blank': False, 'error_type': 'stop',
#                             'error_title': 'Unité invalide',
#                             'error_message': "Choisissez l'unité depuis la liste.",
#                         })
#                     next_hcol += 1
#
#                     # Category helper = existing + refs to 'Catégories'!A2..A..
#                     cat_sheet = SHEET_TITLES["product.category"]
#                     existing_n = len(existing_categories)
#                     _helper_fill_column(ws, next_hcol, existing_categories)
#                     for j in range(1, MAX_ROWS + 1):
#                         ws.write_formula(existing_n + j, next_hcol, f"='{cat_sheet}'!$A${j + 1}")
#
#                     # dropdown on Column D (index 3) using SAME-SHEET helper
#                     ws.data_validation(1, 3, MAX_ROWS, 3, {
#                         'validate': 'list',
#                         'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
#                         'ignore_blank': True, 'error_type': 'stop',
#                         'error_title': 'Catégorie invalide',
#                         'error_message': "Choisissez une catégorie depuis la liste.",
#                     })
#                     next_hcol += 1
#
#
#
#
#                 elif sheet_key == "mrp.bom.semi_finished":
#
#                     # ---- layout constants ----
#
#                     COMPONENT_ROWS_DEFAULT = 10  # default number of component rows
#
#                     BLOCK_ROWS = 1 + COMPONENT_ROWS_DEFAULT  # 1 header + 10 components
#
#                     START_ROW = 1  # 0-based (row 2 in Excel)
#
#                     # Example header + first component (rest will be empty rows ready to fill)
#
#                     p0 = (semi_finished_variants[0] if semi_finished_variants else "Produit semi-fini A")
#
#
#                     u0 = (uom_names[0] if uom_names else "")
#
#                     comp0 = raw_variants[0] if raw_variants else "Matière Première A"
#
#                     example = [p0, "BOM-001", "1", u0, "normal", comp0, "2", u0]
#
#                     # Put the example header/first line
#
#                     for c, v in enumerate(example):
#                         ws.write(START_ROW, c, v, fmt_unlocked)
#
#                     # ---- UoM helper -> validations on D (bom_uom) & H (component_uom) ----
#
#                     if uom_names:
#
#                         _helper_fill_column(ws, next_hcol, uom_names)
#
#                         ucol = next_hcol
#
#                         # Apply validation for all rows in the block (header + components)
#
#                         for col_idx in (3, 7):  # D and H
#
#                             ws.data_validation(
#
#                                 START_ROW, col_idx, START_ROW + BLOCK_ROWS - 1, col_idx,
#
#                                 {
#
#                                     'validate': 'list',
#
#                                     'source': f"${colname(ucol)}$1:${colname(ucol)}${len(uom_names)}",
#
#                                     'ignore_blank': False, 'error_type': 'stop',
#
#                                     'error_title': 'Unité invalide',
#
#                                     'error_message': "Choisissez l'unité depuis la liste.",
#
#                                 }
#
#                             )
#
#                         next_hcol += 1
#
#                     # ---- Produit fabriqué (A) must come from “Produits – Semi-finis” (only on the header row) ----
#
#                     semi_sheet = SHEET_TITLES["product.semi_finished"]
#
#                     existing_n = len(semi_finished_variants)
#
#                     # Hidden helper column on the SAME sheet with DB semi-finished product variants
#                     _helper_fill_column(ws, next_hcol, semi_finished_variants)
#
#                     # Append references to names typed in the “Produits – Semi-finis” sheet (A2..A..)
#                     for j in range(1, MAX_ROWS + 1):
#                         ws.write_formula(existing_n + j, next_hcol, f"='{semi_sheet}'!$A${j + 1}")
#
#                     # Dropdown on column A (only the header row because A is merged over the block)
#                     ws.data_validation(
#                         START_ROW, 0, START_ROW, 0,
#                         {
#                             'validate': 'list',
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${max(1, existing_n + MAX_ROWS)}",
#                             'ignore_blank': False, 'error_type': 'stop',
#                             'error_title': 'Produit invalide',
#                             'error_message': "Choisissez un produit semi-fini existant (ou ajoutez-le dans 'Produits – Semi-finis').",
#                         }
#                     )
#
#                     next_hcol += 1
#                     # ---- Components (F) from union: DB purchasables ∪ “Produits – MP” ----
#
#                     raw_sheet = SHEET_TITLES["product.raw"]
#
#                     existing_n = len(purchasable_variants)
#
#                     _helper_fill_column(ws, next_hcol,
#                                         purchasable_variants)  # write DB purchasables in hidden helper col
#
#                     # append references to the MP typed names on the 'Produits – MP' sheet (A2..A..)
#
#                     for j in range(1, MAX_ROWS + 1):
#                         ws.write_formula(existing_n + j,     next_hcol, f"='{raw_sheet}'!$A${j + 1}")
#
#                     # Validation over the full component column range (F) for the whole block
#
#                     ws.data_validation(
#
#                         START_ROW, 5, START_ROW + BLOCK_ROWS - 1, 5,
#
#                         {
#
#                             'validate': 'list',
#
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
#
#                             'ignore_blank': False, 'error_type': 'stop',
#
#                             'error_title': 'Composant invalide',
#
#                             'error_message': "Choisissez une MP (feuille 'Produits – MP' ou article achetable existant).",
#
#                         }
#
#                     )
#
#                     next_hcol += 1
#
#                     ws.set_column(4, 4, None, fmt_unlocked,
#                                   {'hidden': True})
#                     ws.write(START_ROW, 4, "normal", fmt_unlocked)
#
#                     # ---- Merge A–D over the entire block (header + components) ----
#
#                     ws.merge_range(START_ROW, 0, START_ROW + BLOCK_ROWS - 1, 0, example[0], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 1, START_ROW + BLOCK_ROWS - 1, 1, example[1], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 2, START_ROW + BLOCK_ROWS - 1, 2, example[2], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 3, START_ROW + BLOCK_ROWS - 1, 3, example[3], fmt_unlocked_center)
#
#                     # ---- Optional cosmetics: borders + freeze panes ----
#
#                     ws.freeze_panes(1, 0)  # freeze headers row
#
#                     border = wb.add_format({'border': 1})
#
#                     # Pre-fill the remaining component rows with blanks (so the borders show)
#
#                     # Block is rows [START_ROW .. START_ROW + BLOCK_ROWS - 1]
#
#                     for r in range(START_ROW, START_ROW + BLOCK_ROWS):
#                         for c in range(0, 8):  # A..H
#                             if r == START_ROW and c < 5:
#                                 continue
#                             ws.write_blank(r, c, None, border_unlocked)
#
#                     # Hint line right after the block
#
#                     ws.write(
#
#                         START_ROW + BLOCK_ROWS, 0,
#
#                         "Astuce : insérez/supprimez des lignes à l’intérieur du bloc pour ajuster le nombre de composants ; "
#
#                         "les cellules fusionnées et les validations s’adapteront.",
#
#                         wb.add_format({'italic': True})
#
#                     )
#
#
#
#                 elif sheet_key == "mrp.bom.finished":
#
#                     # ---- same merged-block layout as semi-finished, but tailored to finished ----
#
#                     COMPONENT_ROWS_DEFAULT = 10
#
#                     BLOCK_ROWS = 1 + COMPONENT_ROWS_DEFAULT  # 1 header + 10 components
#
#                     START_ROW = 1  # row 2 in Excel
#
#                     border = wb.add_format({'border': 1})
#
#                     # Example header + first component
#
#                     p0 = (pos_finished_variants[0] if pos_finished_variants else "Produit fini POS A")
#
#                     u0 = (uom_names[0] if uom_names else "")
#
#                     comp0 = raw_variants[0] if raw_variants else "Composant A"
#
#                     example = [p0, "BOM-001", "1", u0, "phantom", comp0, "2", u0]
#
#                     # Put example header/first line
#
#                     for c, v in enumerate(example):
#                         ws.write(START_ROW, c, v, fmt_unlocked)
#
#                     # UoM helper -> validations on D (bom_uom) & H (component_uom) for the whole block
#
#                     if uom_names:
#
#                         _helper_fill_column(ws, next_hcol, uom_names)
#
#                         ucol = next_hcol
#
#                         for col_idx in (3, 7):  # D & H
#
#                             ws.data_validation(
#
#                                 START_ROW, col_idx, START_ROW + BLOCK_ROWS - 1, col_idx,
#
#                                 {
#
#                                     'validate': 'list',
#
#                                     'source': f"${colname(ucol)}$1:${colname(ucol)}${len(uom_names)}",
#
#                                     'ignore_blank': False, 'error_type': 'stop',
#
#                                     'error_title': 'Unité invalide',
#
#                                     'error_message': "Choisissez l'unité depuis la liste.",
#
#                                 }
#
#                             )
#
#                         next_hcol += 1
#
#                     # Column A (Produit fini) -> ONLY POS-enabled finished products from hidden helper column
#
#                     _helper_fill_column(ws, next_hcol, pos_finished_variants)
#
#                     ws.data_validation(
#
#                         START_ROW, 0, START_ROW, 0,  # only header row is editable; the block is merged
#
#                         {
#
#                             'validate': 'list',
#
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${max(1, len(pos_finished_variants))}",
#
#                             'ignore_blank': False, 'error_type': 'stop',
#
#                             'error_title': 'Produit fini invalide',
#
#                             'error_message': "Choisissez un produit fini PoS existant (vendu en PoS).",
#
#                         }
#
#                     )
#
#                     next_hcol += 1
#
#                     # Components (F) from union: DB purchasables ∪ “Produits – MP”
#
#                     raw_sheet = SHEET_TITLES["product.raw"]
#
#                     existing_n = len(purchasable_variants)
#
#                     _helper_fill_column(ws, next_hcol, purchasable_variants)
#
#                     for j in range(1, MAX_ROWS + 1):
#                         ws.write_formula(existing_n + j,     next_hcol, f"='{raw_sheet}'!$A${j + 1}")
#
#                     ws.data_validation(
#
#                         START_ROW, 5, START_ROW + BLOCK_ROWS - 1, 5,
#
#                         {
#
#                             'validate': 'list',
#
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${existing_n + MAX_ROWS}",
#
#                             'ignore_blank': False, 'error_type': 'stop',
#
#                             'error_title': 'Composant invalide',
#
#                             'error_message': "Choisissez une MP (feuille 'Produits – MP' ou article achetable existant).",
#
#                         }
#
#                     )
#
#                     next_hcol += 1
#
#                     # Hide the Type column (E) – fixed 'phantom' for finished products
#
#                     ws.set_column(4, 4, None, fmt_unlocked,
#                                   {'hidden': True})
#                     ws.write(START_ROW, 4, "phantom", fmt_unlocked)
#
#                     # Merge A–D across the block (header + components)
#
#                     ws.merge_range(START_ROW, 0, START_ROW + BLOCK_ROWS - 1, 0, example[0], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 1, START_ROW + BLOCK_ROWS - 1, 1, example[1], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 2, START_ROW + BLOCK_ROWS - 1, 2, example[2], fmt_unlocked_center)
#                     ws.merge_range(START_ROW, 3, START_ROW + BLOCK_ROWS - 1, 3, example[3], fmt_unlocked_center)
#
#                     ws.freeze_panes(1, 0)
#
#                     # Borders/blanks to show the block
#
#                     for r in range(START_ROW, START_ROW + BLOCK_ROWS):
#                         for c in range(0, 8):  # A..H
#                             if r == START_ROW and c < 5:
#                                 continue
#                             ws.write_blank(r, c, None, border_unlocked)
#
#                     ws.write(
#
#                         START_ROW + BLOCK_ROWS, 0,
#
#                         "Astuce : insérez/supprimez des lignes à l’intérieur du bloc pour ajuster le nombre de composants ; "
#
#                         "les cellules fusionnées et validations s’adaptent.",
#
#                         wb.add_format({'italic': True})
#
#                     )
#
#                 elif sheet_key == "stock.location":
#                     # Example
#                     for c, v in enumerate(["Test", "WH", "internal"]):
#                         ws.write(1, c, v)
#
#                     # Parent helper -> column B (1)
#                     if parent_loc_names:
#                         _helper_fill_column(ws, next_hcol, parent_loc_names)
#                         ws.data_validation(1, 1, MAX_ROWS, 1, {
#                             'validate': 'list',
#                             'source': f"${colname(next_hcol)}$1:${colname(next_hcol)}${len(parent_loc_names)}",
#                             'ignore_blank': True, 'error_type': 'stop',
#                             'error_title': 'Parent invalide',
#                             'error_message': 'Choisissez un parent de la liste.',
#                         })
#                         next_hcol += 1
#
#                     # Usage dropdown (static) -> column C (2)
#                     ws.data_validation(1, 2, MAX_ROWS, 2, {
#                         'validate': 'list',
#                         'source': USAGE_CHOICES,
#                         'ignore_blank': False, 'error_type': 'stop',
#                         'error_title': 'Type invalide',
#                         'error_message': 'Choisissez un type de la liste.',
#                     })
#
#                 return ws
#
#             # Build all sheets in the defined order
#             for key in SHEET_IMPORT_ORDER:
#                 _build_sheet(key)
#
#             wb.close()
#
#         else:
#             # Minimal openpyxl fallback (no data validations / helpers)
#             from openpyxl import Workbook
#             from openpyxl.utils import get_column_letter
#
#             wb = Workbook()
#             first = True
#             for key in SHEET_IMPORT_ORDER:
#                 if first:
#                     ws = wb.active
#                     ws.title = SHEET_TITLES[key]
#                     first = False
#                 else:
#                     ws = wb.create_sheet(SHEET_TITLES[key])
#                 headers = HEADER_LABELS.get(key, [])
#                 for c, (_k, lbl) in enumerate(headers, start=1):
#                     ws.cell(row=1, column=c, value=lbl)
#                     ws.column_dimensions[get_column_letter(c)].width = 28
#                 # simple example rows
#                 if key == "product.category":
#                     ex = ["Catégorie A", ""]
#                 elif key in ("product.raw", "product.semi_finished", "product.finished"):
#                     u0 = uom_names[0] if uom_names else ""
#                     if key == "product.semi_finished":
#                         c_default = semi_cat_name or (existing_categories[0] if existing_categories else "")
#                     else:
#                         c_default = existing_categories[0] if existing_categories else ""
#                     ex = ["Produit A", u0, "199.99", c_default]
#                 elif key == "mrp.bom.semi_finished":
#                     u0 = uom_names[0] if uom_names else ""
#                     p0 = semi_finished_variants[0] if semi_finished_variants else "Produit Semi-fini A"
#                     comp0 = raw_variants[0] if raw_variants else "Matière Première A"
#                     ex = [p0, "BOM-001", "1", u0, "normal", comp0, "2", u0]
#                 elif key == "mrp.bom.finished":
#                     u0 = uom_names[0] if uom_names else ""
#                     ex = ["Produit Fini A", "BOM-001", "1", u0, "normal", "Composant A", "2", u0]
#                 else:
#                     ex = ["Test", "WH", "internal"]
#                 for c, v in enumerate(ex, start=1):
#                     ws.cell(row=2, column=c, value=v)
#
#             wb.save(output)
#
#         content = output.getvalue()
#         output.close()
#
#         att = self.env["ir.attachment"].create({
#             "name": "Modele_Master_Import.xlsx",
#             "type": "binary",
#             "datas": base64.b64encode(content),
#             "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
#             "res_model": self._name,
#             "res_id": self.id,
#         })
#         url = f"/web/content/{att.id}?download=true"
#         return {"type": "ir.actions.act_url", "url": url, "target": "self"}
#
#     def action_test_master(self):
#         """Validate all present sheets without writing, using the same collector
#         as import (supports merged/carry-forward BOM headers)."""
#         self.ensure_one()
#         wb = self._read_workbook()
#
#         total_rows = 0
#         total_errors = 0
#         lines = []
#         found_titles = []
#
#         # --- original small helpers (kept for readability / future use) ---
#         def _c1(c0):
#             return (c0 or 0) + 1
#
#         # -------------------------------------------------------------------
#
#         for sheet_key in SHEET_IMPORT_ORDER:
#             sheet_title = SHEET_TITLES.get(sheet_key, sheet_key)
#             if sheet_title not in wb.sheetnames:
#                 continue
#
#             found_titles.append(sheet_title)
#             ws = wb[sheet_title]
#
#             # Parse headers once per sheet
#             try:
#                 hmap, body = self._parse_worksheet(ws, sheet_key)
#             except Exception as e:
#                 lines.append(f"[{sheet_title}]")
#                 lines.append(f"✖ {sheet_title}: header error — {e}")
#                 lines.append("")
#                 total_errors += 1
#                 continue
#
#             # No data rows present
#             if not body or not any(any(c for c in r) for r in body):
#                 lines.append(f"✔ {sheet_title}: no data rows — OK")
#                 lines.append("")
#                 continue
#
#             # ✅ Single source of truth: use _collect (handles merged A–D on BOM sheets)
#             records, log, count, errors = self._collect(hmap, body, sheet_key)
#
#             total_rows += count
#             total_errors += errors
#
#             if errors == 0:
#                 lines.append(f"✔ {sheet_title}: OK — {count} row(s) checked")
#             else:
#                 lines.append(f"[{sheet_title}]")
#                 # _collect already produced human-readable "Line N: ..." logs
#                 lines.extend(log)
#                 lines.append(f"✖ {sheet_title}: {errors} issue(s) in {count} row(s)")
#             lines.append("")
#
#         header = [
#             _("=== MASTER TEST RESULT ==="),
#             _("Sheets found: %s") % (", ".join(found_titles) if found_titles else "-"),
#             _("Total rows checked: %s") % total_rows,
#             _("Total issues: %s") % total_errors,
#             ""
#         ]
#
#         self.write({
#             "log_text": "\n".join(header + lines),
#             "line_count": total_rows,
#             "error_count": total_errors,
#             "tested_ok": total_errors == 0 and bool(found_titles),
#         })
#         return {
#             "type": "ir.actions.act_window",
#             "res_model": self._name,
#             "res_id": self.id,
#             "view_mode": "form",
#             "target": "new",
#         }
#
#     def action_import_master(self):
#         self.ensure_one()
#         wb = self._read_workbook()
#
#         created_total = updated_total = scanned_total = 0
#         details_all = []
#         processed_titles = []
#
#         # 👇 track which semi-finished names came from the workbook (None means the sheet wasn't present)
#         semi_sheet_names = None
#         raw_sheet_names = None
#
#         # NEW: DB purchasable names (variants)
#         PP = self.env["product.product"]
#         db_purchasable_names = set(PP.search([("purchase_ok", "=", True)]).mapped("name"))
#
#         # First pass: we’ll import products as usual and remember semi-finis names from the sheet
#         for sheet_key in SHEET_IMPORT_ORDER:
#             sheet_title = SHEET_TITLES.get(sheet_key, sheet_key)
#             if sheet_title not in wb.sheetnames:
#                 continue
#
#             processed_titles.append(sheet_title)
#             ws = wb[sheet_title]
#             hmap, body = self._parse_worksheet(ws, sheet_key)
#             if not body or not any(any(c for c in r) for r in body):
#                 details_all.append(f"[{sheet_title}] (empty) — skipped")
#                 continue
#
#             records, log, count, errors = self._collect(hmap, body, sheet_key)
#             scanned_total += count
#             if errors:
#                 raise ValidationError(_("Sheet '%s': please fix errors first. Issues found: %s\n\n%s") %
#                                       (sheet_title, errors, "\n".join(log[:50])))
#
#             if sheet_key == "product.category":
#                 c, u, det = self._import_categories(records)
#
#             elif sheet_key in ("product.raw", "product.semi_finished", "product.finished"):
#                 # Remember names from the Semi-finis sheet so BOMs must use only these
#                 if sheet_key == "product.semi_finished":
#                     semi_sheet_names = {self._norm(r.get("name")) for r in records if r.get("name")}
#                 if sheet_key == "product.raw":
#                     raw_sheet_names = {self._norm(r.get("name")) for r in records if r.get("name")}
#                 c, u, det = self._import_products(records, sheet_key)
#
#             elif sheet_key == "mrp.bom.semi_finished":
#                 PP = self.env["product.product"]
#                 db_purch = {self._norm(n) for n in PP.search([("purchase_ok", "=", True)]).mapped("name")}
#                 allowed_components = db_purch | (raw_sheet_names or set())
#                 c, u, det = self._import_boms_semi_finished(
#                     records,
#                     allowed_names=(semi_sheet_names if semi_sheet_names is not None else None),
#                     allowed_components=allowed_components,
#                 )
#
#             elif sheet_key == "mrp.bom.finished":
#                 PP = self.env["product.product"]
#                 db_purch = {self._norm(n) for n in PP.search([("purchase_ok", "=", True)]).mapped("name")}
#                 allowed_components = db_purch | (raw_sheet_names or set())
#                 c, u, det = self._import_boms_finished(records, allowed_components=allowed_components)
#
#             elif sheet_key == "stock.location":
#                 c, u, det = self._import_locations(records)
#
#             else:
#                 details_all.append(f"[{sheet_title}] unsupported sheet key '{sheet_key}' — skipped")
#                 continue
#
#             created_total += c
#             updated_total += u
#             details_all.append(f"[{sheet_title}] OK — rows: {count}, created: {c}, updated: {u}")
#             details_all.extend([f"[{sheet_title}] {d}" for d in (det[:200] if det else [])])
#
#         summary = [
#             _("=== MASTER IMPORT RESULT ==="),
#             _("Sheets processed (order): %s") % (", ".join(processed_titles) or "-"),
#             _("Rows scanned: %s") % scanned_total,
#             _("Created: %s") % created_total,
#             _("Updated: %s") % updated_total,
#             ""
#         ]
#         self.write({
#             "log_text": "\n".join(summary + details_all),
#             "tested_ok": True,
#             "line_count": scanned_total,
#             "error_count": 0,
#         })
#         return {
#             "type": "ir.actions.act_window",
#             "res_model": self._name,
#             "res_id": self.id,
#             "view_mode": "form",
#             "target": "new",
#         }

# -*- coding: utf-8 -*-
import base64
from io import BytesIO

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

try:
    from openpyxl import load_workbook
except Exception:
    load_workbook = None

# services
from ..services import constants as C
from ..services import xlsx_builder as XB
from ..services import collectors as COL
from ..services import importers as IMP
from ..services import resolvers as R


class CmMasterImportWizard(models.TransientModel):
    _name = "cm.master.import.wizard"
    _description = "Master Import Wizard (All-in-One XLSX)"

    file = fields.Binary("Excel (.xlsx)")
    filename = fields.Char()
    log_text = fields.Text(readonly=True)
    line_count = fields.Integer(readonly=True)
    error_count = fields.Integer(readonly=True)
    tested_ok = fields.Boolean(readonly=True)

    @api.model
    def action_open_master_wizard(self):
        wiz = self.create({})
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": wiz.id,
            "view_mode": "form",
            "target": "new",
        }

    # --- helpers ---
    def _require_openpyxl(self):
        if load_workbook is None:
            raise UserError(_("Missing Python dependency: openpyxl"))

    def _read_workbook(self):
        self._require_openpyxl()
        if not self.file:
            raise UserError(_("Please upload an .xlsx file."))
        try:
            stream = BytesIO(base64.b64decode(self.file))
            wb = load_workbook(stream, read_only=True, data_only=True)
            return wb
        except Exception as e:
            raise UserError(_("Could not read file: %s") % e)

    # --- actions ---
    def action_download_master_template(self):
        self.ensure_one()
        filename, content = XB.build_master_template(self.env)
        att = self.env["ir.attachment"].create({
            "name": filename,
            "type": "binary",
            "datas": base64.b64encode(content),
            "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "res_model": self._name,
            "res_id": self.id,
        })
        return {"type": "ir.actions.act_url", "url": f"/web/content/{att.id}?download=true", "target": "self"}

    def action_test_master(self):
        self.ensure_one()
        wb = self._read_workbook()

        total_rows = 0
        total_errors = 0
        lines = []
        found_titles = []

        for sheet_key in C.SHEET_IMPORT_ORDER:
            sheet_title = C.SHEET_TITLES.get(sheet_key, sheet_key)
            if sheet_title not in wb.sheetnames:
                continue

            found_titles.append(sheet_title)
            ws = wb[sheet_title]

            try:
                hmap, body = XB.parse_worksheet_strict(ws, sheet_key)
            except Exception as e:
                lines.append(f"[{sheet_title}]")
                lines.append(f"✖ {sheet_title}: header error — {e}")
                lines.append("")
                total_errors += 1
                continue

            if not body or not any(any(c for c in r) for r in body):
                lines.append(f"✔ {sheet_title}: no data rows — OK")
                lines.append("")
                continue

            records, log, count, errors = COL.collect(self.env, hmap, body, sheet_key)
            total_rows += count
            total_errors += errors

            if errors == 0:
                lines.append(f"✔ {sheet_title}: OK — {count} row(s) checked")
            else:
                lines.append(f"[{sheet_title}]")
                lines.extend(log)
                lines.append(f"✖ {sheet_title}: {errors} issue(s) in {count} row(s)")
            lines.append("")

        header = [
            _("=== MASTER TEST RESULT ==="),
            _("Sheets found: %s") % (", ".join(found_titles) if found_titles else "-"),
            _("Total rows checked: %s") % total_rows,
            _("Total issues: %s") % total_errors,
            ""
        ]
        self.write({
            "log_text": "\n".join(header + lines),
            "line_count": total_rows,
            "error_count": total_errors,
            "tested_ok": total_errors == 0 and bool(found_titles),
        })
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }

    def action_import_master(self):
        self.ensure_one()
        wb = self._read_workbook()

        created_total = updated_total = scanned_total = 0
        details_all = []
        processed_titles = []

        semi_sheet_names = None
        raw_sheet_names = None

        for sheet_key in C.SHEET_IMPORT_ORDER:
            sheet_title = C.SHEET_TITLES.get(sheet_key, sheet_key)
            if sheet_title not in wb.sheetnames:
                continue

            processed_titles.append(sheet_title)
            ws = wb[sheet_title]
            hmap, body = XB.parse_worksheet_strict(ws, sheet_key)
            if not body or not any(any(c for c in r) for r in body):
                details_all.append(f"[{sheet_title}] (empty) — skipped")
                continue

            records, log, count, errors = COL.collect(self.env, hmap, body, sheet_key)
            scanned_total += count
            if errors:
                raise ValidationError(_("Sheet '%s': please fix errors first. Issues found: %s\n\n%s") %
                                      (sheet_title, errors, "\n".join(log[:50])))

            if sheet_key == "product.category":
                c, u, det = IMP.import_categories(self.env, records)
            elif sheet_key in ("product.raw", "product.semi_finished", "product.finished"):
                if sheet_key == "product.semi_finished":
                    semi_sheet_names = {R.norm(r.get("name")) for r in records if r.get("name")}
                if sheet_key == "product.raw":
                    raw_sheet_names = {R.norm(r.get("name")) for r in records if r.get("name")}
                c, u, det = IMP.import_products(self.env, records, sheet_key)
            elif sheet_key == "mrp.bom.semi_finished":
                c, u, det = IMP.import_boms_semi_finished(self.env, records, semi_sheet_names, raw_sheet_names)
            elif sheet_key == "mrp.bom.finished":
                c, u, det = IMP.import_boms_finished(self.env, records, raw_sheet_names)
            elif sheet_key == "stock.location":
                c, u, det = IMP.import_locations(self.env, records)
            else:
                details_all.append(f"[{sheet_title}] unsupported sheet key '{sheet_key}' — skipped")
                continue

            created_total += c
            updated_total += u
            details_all.append(f"[{sheet_title}] OK — rows: {count}, created: {c}, updated: {u}")
            details_all.extend([f"[{sheet_title}] {d}" for d in (det[:200] if det else [])])

        summary = [
            _("=== MASTER IMPORT RESULT ==="),
            _("Sheets processed (order): %s") % (", ".join(processed_titles) or "-"),
            _("Rows scanned: %s") % scanned_total,
            _("Created: %s") % created_total,
            _("Updated: %s") % updated_total,
            ""
        ]
        self.write({
            "log_text": "\n".join(summary + details_all),
            "tested_ok": True,
            "line_count": scanned_total,
            "error_count": 0,
        })
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }
